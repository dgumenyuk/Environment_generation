.. automodule:: scipy.signal
