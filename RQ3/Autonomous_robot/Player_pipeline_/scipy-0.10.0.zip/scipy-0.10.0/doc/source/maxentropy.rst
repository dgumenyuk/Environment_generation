.. automodule:: scipy.maxentropy
