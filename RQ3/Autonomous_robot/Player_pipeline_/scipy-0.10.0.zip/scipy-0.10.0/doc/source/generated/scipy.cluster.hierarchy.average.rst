scipy.cluster.hierarchy.average
===============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: average