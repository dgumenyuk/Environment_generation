scipy.maxentropy.basemodel.beginlogging
=======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.beginlogging