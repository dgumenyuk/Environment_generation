scipy.maxentropy.conditionalmodel.setfeaturesandsamplespace
===========================================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.setfeaturesandsamplespace