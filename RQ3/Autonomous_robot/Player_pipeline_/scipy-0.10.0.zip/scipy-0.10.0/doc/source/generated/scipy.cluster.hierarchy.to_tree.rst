scipy.cluster.hierarchy.to_tree
===============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: to_tree