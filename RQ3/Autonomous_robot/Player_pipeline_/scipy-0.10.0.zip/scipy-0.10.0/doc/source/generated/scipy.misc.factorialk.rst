scipy.misc.factorialk
=====================

.. currentmodule:: scipy.misc

.. autofunction:: factorialk