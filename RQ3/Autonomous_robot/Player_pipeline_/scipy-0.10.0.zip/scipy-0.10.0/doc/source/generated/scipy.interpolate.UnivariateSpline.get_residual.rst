scipy.interpolate.UnivariateSpline.get_residual
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.get_residual