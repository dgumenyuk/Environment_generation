scipy.interpolate.InterpolatedUnivariateSpline.derivatives
==========================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.derivatives