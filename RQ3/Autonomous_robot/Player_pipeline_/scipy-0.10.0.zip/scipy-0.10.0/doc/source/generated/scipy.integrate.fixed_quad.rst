scipy.integrate.fixed_quad
==========================

.. currentmodule:: scipy.integrate

.. autofunction:: fixed_quad