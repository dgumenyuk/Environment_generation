scipy.ndimage.filters.correlate
===============================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: correlate