scipy.linalg.sinm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: sinm