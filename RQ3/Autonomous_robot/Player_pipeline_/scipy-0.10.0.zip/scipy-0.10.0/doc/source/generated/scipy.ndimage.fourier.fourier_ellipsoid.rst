scipy.ndimage.fourier.fourier_ellipsoid
=======================================

.. currentmodule:: scipy.ndimage.fourier

.. autofunction:: fourier_ellipsoid