scipy.interpolate.InterpolatedUnivariateSpline.get_coeffs
=========================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.get_coeffs