scipy.interpolate.interp1d
==========================

.. currentmodule:: scipy.interpolate

.. autoclass:: interp1d

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         interp1d.__call__



   

