scipy.maxentropy.basemodel
==========================

.. currentmodule:: scipy.maxentropy

.. autoclass:: basemodel

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         basemodel.beginlogging
         basemodel.clearcache
         basemodel.crossentropy
         basemodel.dual
         basemodel.endlogging
         basemodel.entropydual
         basemodel.fit
         basemodel.grad
         basemodel.log
         basemodel.logparams
         basemodel.normconst
         basemodel.reset
         basemodel.setcallback
         basemodel.setparams
         basemodel.setsmooth



   

