scipy.integrate.ode.set_f_params
================================

.. currentmodule:: scipy.integrate

.. automethod:: ode.set_f_params