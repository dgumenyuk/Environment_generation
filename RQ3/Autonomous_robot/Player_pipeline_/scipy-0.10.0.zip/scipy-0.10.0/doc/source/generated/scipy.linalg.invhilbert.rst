scipy.linalg.invhilbert
=======================

.. currentmodule:: scipy.linalg

.. autofunction:: invhilbert