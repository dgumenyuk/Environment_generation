scipy.ndimage.filters.gaussian_laplace
======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: gaussian_laplace