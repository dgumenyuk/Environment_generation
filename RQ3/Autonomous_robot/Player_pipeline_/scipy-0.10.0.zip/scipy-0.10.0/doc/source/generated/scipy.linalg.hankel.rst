scipy.linalg.hankel
===================

.. currentmodule:: scipy.linalg

.. autofunction:: hankel