scipy.interpolate.PiecewisePolynomial.__call__
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: PiecewisePolynomial.__call__