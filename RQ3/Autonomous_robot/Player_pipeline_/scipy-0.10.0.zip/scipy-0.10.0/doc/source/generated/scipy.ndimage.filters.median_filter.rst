scipy.ndimage.filters.median_filter
===================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: median_filter