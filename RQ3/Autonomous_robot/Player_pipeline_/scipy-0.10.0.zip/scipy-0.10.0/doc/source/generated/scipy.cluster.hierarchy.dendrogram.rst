scipy.cluster.hierarchy.dendrogram
==================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: dendrogram