scipy.ndimage.filters.minimum_filter
====================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: minimum_filter