scipy.maxentropy.bigmodel.log
=============================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.log