scipy.fftpack.irfft
===================

.. currentmodule:: scipy.fftpack

.. autofunction:: irfft