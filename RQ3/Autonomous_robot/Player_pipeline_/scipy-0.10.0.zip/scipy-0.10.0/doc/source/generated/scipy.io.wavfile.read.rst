scipy.io.wavfile.read
=====================

.. currentmodule:: scipy.io.wavfile

.. autofunction:: read