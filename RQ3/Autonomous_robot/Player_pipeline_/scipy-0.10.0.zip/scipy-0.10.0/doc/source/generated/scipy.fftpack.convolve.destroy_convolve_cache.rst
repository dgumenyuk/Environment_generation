scipy.fftpack.convolve.destroy_convolve_cache
=============================================

.. currentmodule:: scipy.fftpack.convolve

.. autodata:: destroy_convolve_cache