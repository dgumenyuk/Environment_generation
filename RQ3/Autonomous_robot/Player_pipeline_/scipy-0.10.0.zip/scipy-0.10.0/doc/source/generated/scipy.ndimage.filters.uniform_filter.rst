scipy.ndimage.filters.uniform_filter
====================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: uniform_filter