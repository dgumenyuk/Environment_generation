scipy.maxentropy.bigmodel.pdf_function
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.pdf_function