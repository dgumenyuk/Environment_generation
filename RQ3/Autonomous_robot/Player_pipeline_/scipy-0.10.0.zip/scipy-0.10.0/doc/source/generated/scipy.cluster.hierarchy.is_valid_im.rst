scipy.cluster.hierarchy.is_valid_im
===================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: is_valid_im