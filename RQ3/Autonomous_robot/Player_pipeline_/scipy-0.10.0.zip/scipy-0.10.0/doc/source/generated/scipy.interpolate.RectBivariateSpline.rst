scipy.interpolate.RectBivariateSpline
=====================================

.. currentmodule:: scipy.interpolate

.. autoclass:: RectBivariateSpline

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         RectBivariateSpline.__call__
         RectBivariateSpline.ev
         RectBivariateSpline.get_coeffs
         RectBivariateSpline.get_knots
         RectBivariateSpline.get_residual
         RectBivariateSpline.integral



   

