scipy.interpolate.LSQBivariateSpline.integral
=============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.integral