scipy.linalg.eig
================

.. currentmodule:: scipy.linalg

.. autofunction:: eig