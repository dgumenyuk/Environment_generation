scipy.linalg.signm
==================

.. currentmodule:: scipy.linalg

.. autofunction:: signm