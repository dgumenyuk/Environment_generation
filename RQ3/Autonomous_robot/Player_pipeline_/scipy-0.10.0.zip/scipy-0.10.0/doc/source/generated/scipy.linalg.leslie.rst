scipy.linalg.leslie
===================

.. currentmodule:: scipy.linalg

.. autofunction:: leslie