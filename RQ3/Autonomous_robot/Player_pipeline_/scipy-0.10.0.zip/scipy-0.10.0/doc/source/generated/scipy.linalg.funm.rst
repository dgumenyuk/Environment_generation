scipy.linalg.funm
=================

.. currentmodule:: scipy.linalg

.. autofunction:: funm