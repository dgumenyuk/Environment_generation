scipy.maxentropy.basemodel.log
==============================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.log