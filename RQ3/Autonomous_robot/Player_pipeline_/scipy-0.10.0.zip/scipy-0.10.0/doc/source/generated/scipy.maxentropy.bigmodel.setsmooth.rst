scipy.maxentropy.bigmodel.setsmooth
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.setsmooth