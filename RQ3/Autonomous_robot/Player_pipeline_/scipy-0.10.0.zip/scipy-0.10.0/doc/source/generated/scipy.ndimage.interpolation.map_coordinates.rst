scipy.ndimage.interpolation.map_coordinates
===========================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: map_coordinates