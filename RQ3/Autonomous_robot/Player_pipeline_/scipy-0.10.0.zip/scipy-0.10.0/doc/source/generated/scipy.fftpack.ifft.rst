scipy.fftpack.ifft
==================

.. currentmodule:: scipy.fftpack

.. autofunction:: ifft