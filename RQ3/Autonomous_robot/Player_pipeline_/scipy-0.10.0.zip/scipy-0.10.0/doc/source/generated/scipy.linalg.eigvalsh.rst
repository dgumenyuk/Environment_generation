scipy.linalg.eigvalsh
=====================

.. currentmodule:: scipy.linalg

.. autofunction:: eigvalsh