scipy.maxentropy.bigmodel.settestsamples
========================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.settestsamples