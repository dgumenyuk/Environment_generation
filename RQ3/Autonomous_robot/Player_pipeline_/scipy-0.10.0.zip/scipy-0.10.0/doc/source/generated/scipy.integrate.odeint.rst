scipy.integrate.odeint
======================

.. currentmodule:: scipy.integrate

.. autofunction:: odeint