scipy.ndimage.filters.uniform_filter1d
======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: uniform_filter1d