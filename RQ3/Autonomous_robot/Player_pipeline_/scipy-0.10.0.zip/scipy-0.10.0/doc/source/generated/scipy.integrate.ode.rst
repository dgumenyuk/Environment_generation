scipy.integrate.ode
===================

.. currentmodule:: scipy.integrate

.. autoclass:: ode

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         ode.integrate
         ode.set_f_params
         ode.set_initial_value
         ode.set_integrator
         ode.set_jac_params
         ode.successful



   

