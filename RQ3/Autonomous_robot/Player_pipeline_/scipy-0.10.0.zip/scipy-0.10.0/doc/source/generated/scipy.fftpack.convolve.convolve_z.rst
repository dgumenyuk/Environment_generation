scipy.fftpack.convolve.convolve_z
=================================

.. currentmodule:: scipy.fftpack.convolve

.. autodata:: convolve_z