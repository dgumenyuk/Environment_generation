scipy.ndimage.interpolation.affine_transform
============================================

.. currentmodule:: scipy.ndimage.interpolation

.. autofunction:: affine_transform