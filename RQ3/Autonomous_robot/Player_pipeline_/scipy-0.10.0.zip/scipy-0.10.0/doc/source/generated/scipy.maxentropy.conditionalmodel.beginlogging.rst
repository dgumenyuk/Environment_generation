scipy.maxentropy.conditionalmodel.beginlogging
==============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.beginlogging