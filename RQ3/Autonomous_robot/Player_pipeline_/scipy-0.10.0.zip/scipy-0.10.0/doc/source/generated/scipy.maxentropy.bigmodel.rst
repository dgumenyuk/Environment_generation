scipy.maxentropy.bigmodel
=========================

.. currentmodule:: scipy.maxentropy

.. autoclass:: bigmodel

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         bigmodel.beginlogging
         bigmodel.clearcache
         bigmodel.crossentropy
         bigmodel.dual
         bigmodel.endlogging
         bigmodel.entropydual
         bigmodel.estimate
         bigmodel.expectations
         bigmodel.fit
         bigmodel.grad
         bigmodel.log
         bigmodel.lognormconst
         bigmodel.logparams
         bigmodel.logpdf
         bigmodel.normconst
         bigmodel.pdf
         bigmodel.pdf_function
         bigmodel.resample
         bigmodel.reset
         bigmodel.setcallback
         bigmodel.setparams
         bigmodel.setsampleFgen
         bigmodel.setsmooth
         bigmodel.settestsamples
         bigmodel.stochapprox
         bigmodel.test



   

