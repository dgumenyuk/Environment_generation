scipy.maxentropy.basemodel.setsmooth
====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.setsmooth