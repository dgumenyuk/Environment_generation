scipy.ndimage.filters.rank_filter
=================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: rank_filter