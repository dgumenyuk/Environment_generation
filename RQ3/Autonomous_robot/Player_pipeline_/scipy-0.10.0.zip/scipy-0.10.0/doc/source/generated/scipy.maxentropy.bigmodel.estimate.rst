scipy.maxentropy.bigmodel.estimate
==================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.estimate