scipy.maxentropy.conditionalmodel.fit
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.fit