scipy.interpolate.UnivariateSpline.get_knots
============================================

.. currentmodule:: scipy.interpolate

.. automethod:: UnivariateSpline.get_knots