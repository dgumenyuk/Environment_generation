scipy.cluster.hierarchy.is_isomorphic
=====================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: is_isomorphic