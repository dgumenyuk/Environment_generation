scipy.interpolate.interp2d
==========================

.. currentmodule:: scipy.interpolate

.. autoclass:: interp2d

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         interp2d.__call__



   

