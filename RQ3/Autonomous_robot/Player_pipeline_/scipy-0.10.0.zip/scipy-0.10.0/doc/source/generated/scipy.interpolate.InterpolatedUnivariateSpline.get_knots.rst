scipy.interpolate.InterpolatedUnivariateSpline.get_knots
========================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.get_knots