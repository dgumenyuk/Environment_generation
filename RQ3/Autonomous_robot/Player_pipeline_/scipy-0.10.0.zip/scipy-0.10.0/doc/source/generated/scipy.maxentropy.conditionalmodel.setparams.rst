scipy.maxentropy.conditionalmodel.setparams
===========================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.setparams