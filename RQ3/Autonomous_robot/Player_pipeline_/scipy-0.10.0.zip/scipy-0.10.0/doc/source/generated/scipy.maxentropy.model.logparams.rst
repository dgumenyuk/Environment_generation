scipy.maxentropy.model.logparams
================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.logparams