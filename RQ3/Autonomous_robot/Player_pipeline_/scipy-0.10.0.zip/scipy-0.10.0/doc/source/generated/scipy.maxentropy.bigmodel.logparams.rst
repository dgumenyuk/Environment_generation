scipy.maxentropy.bigmodel.logparams
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.logparams