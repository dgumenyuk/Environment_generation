scipy.maxentropy.basemodel.entropydual
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.entropydual