scipy.linalg.tril
=================

.. currentmodule:: scipy.linalg

.. autofunction:: tril