scipy.io.netcdf.netcdf_variable.isrec
=====================================

.. currentmodule:: scipy.io.netcdf

.. autoattribute:: netcdf_variable.isrec