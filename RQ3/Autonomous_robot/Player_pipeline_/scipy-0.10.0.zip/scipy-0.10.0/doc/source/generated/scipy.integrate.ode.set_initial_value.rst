scipy.integrate.ode.set_initial_value
=====================================

.. currentmodule:: scipy.integrate

.. automethod:: ode.set_initial_value