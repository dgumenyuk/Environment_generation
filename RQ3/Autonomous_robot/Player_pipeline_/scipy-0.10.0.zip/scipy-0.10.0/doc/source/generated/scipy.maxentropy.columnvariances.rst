scipy.maxentropy.columnvariances
================================

.. currentmodule:: scipy.maxentropy

.. autofunction:: columnvariances