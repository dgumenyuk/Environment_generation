scipy.interpolate.krogh_interpolate
===================================

.. currentmodule:: scipy.interpolate

.. autofunction:: krogh_interpolate