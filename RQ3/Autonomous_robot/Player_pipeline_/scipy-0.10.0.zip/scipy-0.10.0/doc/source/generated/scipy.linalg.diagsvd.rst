scipy.linalg.diagsvd
====================

.. currentmodule:: scipy.linalg

.. autofunction:: diagsvd