scipy.cluster.hierarchy.fclusterdata
====================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: fclusterdata