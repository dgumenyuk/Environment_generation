scipy.interpolate.KroghInterpolator.derivatives
===============================================

.. currentmodule:: scipy.interpolate

.. automethod:: KroghInterpolator.derivatives