scipy.interpolate.splev
=======================

.. currentmodule:: scipy.interpolate

.. autofunction:: splev