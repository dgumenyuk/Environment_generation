scipy.maxentropy.conditionalmodel.crossentropy
==============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.crossentropy