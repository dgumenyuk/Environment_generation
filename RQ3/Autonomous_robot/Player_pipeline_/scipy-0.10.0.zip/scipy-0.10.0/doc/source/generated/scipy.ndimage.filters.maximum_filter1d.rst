scipy.ndimage.filters.maximum_filter1d
======================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: maximum_filter1d