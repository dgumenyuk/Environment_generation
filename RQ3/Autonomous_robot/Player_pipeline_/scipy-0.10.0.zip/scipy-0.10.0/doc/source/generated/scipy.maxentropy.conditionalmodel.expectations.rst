scipy.maxentropy.conditionalmodel.expectations
==============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.expectations