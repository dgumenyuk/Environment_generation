scipy.maxentropy.model.entropydual
==================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.entropydual