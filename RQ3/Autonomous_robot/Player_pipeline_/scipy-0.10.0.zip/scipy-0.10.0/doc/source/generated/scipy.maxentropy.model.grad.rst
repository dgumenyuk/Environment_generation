scipy.maxentropy.model.grad
===========================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.grad