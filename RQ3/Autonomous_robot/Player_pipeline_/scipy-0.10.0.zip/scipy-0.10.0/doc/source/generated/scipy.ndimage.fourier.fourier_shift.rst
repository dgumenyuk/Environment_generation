scipy.ndimage.fourier.fourier_shift
===================================

.. currentmodule:: scipy.ndimage.fourier

.. autofunction:: fourier_shift