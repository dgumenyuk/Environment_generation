scipy.interpolate.lagrange
==========================

.. currentmodule:: scipy.interpolate

.. autofunction:: lagrange