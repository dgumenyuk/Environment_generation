scipy.linalg.schur
==================

.. currentmodule:: scipy.linalg

.. autofunction:: schur