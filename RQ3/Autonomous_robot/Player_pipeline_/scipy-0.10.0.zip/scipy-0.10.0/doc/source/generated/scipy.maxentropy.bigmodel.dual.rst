scipy.maxentropy.bigmodel.dual
==============================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.dual