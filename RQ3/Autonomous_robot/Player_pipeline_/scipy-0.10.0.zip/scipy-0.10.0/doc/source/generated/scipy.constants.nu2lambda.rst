scipy.constants.nu2lambda
=========================

.. currentmodule:: scipy.constants

.. autofunction:: nu2lambda