scipy.ndimage.fourier.fourier_gaussian
======================================

.. currentmodule:: scipy.ndimage.fourier

.. autofunction:: fourier_gaussian