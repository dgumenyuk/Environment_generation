scipy.linalg.expm2
==================

.. currentmodule:: scipy.linalg

.. autofunction:: expm2