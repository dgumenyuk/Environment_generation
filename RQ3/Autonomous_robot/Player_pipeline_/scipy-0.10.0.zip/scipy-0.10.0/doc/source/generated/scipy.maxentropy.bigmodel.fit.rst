scipy.maxentropy.bigmodel.fit
=============================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.fit