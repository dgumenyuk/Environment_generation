scipy.linalg.solveh_banded
==========================

.. currentmodule:: scipy.linalg

.. autofunction:: solveh_banded