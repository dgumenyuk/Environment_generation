scipy.io.mmread
===============

.. currentmodule:: scipy.io

.. autofunction:: mmread