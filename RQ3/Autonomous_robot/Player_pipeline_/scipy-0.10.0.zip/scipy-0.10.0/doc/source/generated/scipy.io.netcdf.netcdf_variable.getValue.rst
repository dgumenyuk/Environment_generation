scipy.io.netcdf.netcdf_variable.getValue
========================================

.. currentmodule:: scipy.io.netcdf

.. automethod:: netcdf_variable.getValue