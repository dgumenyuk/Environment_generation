scipy.interpolate.SmoothBivariateSpline.get_coeffs
==================================================

.. currentmodule:: scipy.interpolate

.. automethod:: SmoothBivariateSpline.get_coeffs