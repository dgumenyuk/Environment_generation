scipy.maxentropy.bigmodel.grad
==============================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.grad