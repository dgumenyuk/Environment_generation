scipy.linalg.hadamard
=====================

.. currentmodule:: scipy.linalg

.. autofunction:: hadamard