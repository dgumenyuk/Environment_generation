scipy.cluster.hierarchy.leaves_list
===================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: leaves_list