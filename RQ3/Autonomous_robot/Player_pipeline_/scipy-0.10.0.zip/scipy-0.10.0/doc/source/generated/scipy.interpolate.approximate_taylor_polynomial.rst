scipy.interpolate.approximate_taylor_polynomial
===============================================

.. currentmodule:: scipy.interpolate

.. autofunction:: approximate_taylor_polynomial