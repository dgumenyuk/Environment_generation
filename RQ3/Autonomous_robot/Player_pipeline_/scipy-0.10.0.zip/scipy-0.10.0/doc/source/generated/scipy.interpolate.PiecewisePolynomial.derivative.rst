scipy.interpolate.PiecewisePolynomial.derivative
================================================

.. currentmodule:: scipy.interpolate

.. automethod:: PiecewisePolynomial.derivative