scipy.fftpack._fftpack.destroy_zfft_cache
=========================================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: destroy_zfft_cache