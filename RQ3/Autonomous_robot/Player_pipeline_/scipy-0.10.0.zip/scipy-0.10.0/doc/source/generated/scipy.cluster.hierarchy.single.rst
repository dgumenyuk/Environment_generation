scipy.cluster.hierarchy.single
==============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: single