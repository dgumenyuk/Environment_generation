scipy.maxentropy.basemodel.fit
==============================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.fit