scipy.misc.bytescale
====================

.. currentmodule:: scipy.misc

.. autofunction:: bytescale