scipy.maxentropy.model.log
==========================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.log