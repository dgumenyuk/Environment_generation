scipy.linalg.qr
===============

.. currentmodule:: scipy.linalg

.. autofunction:: qr