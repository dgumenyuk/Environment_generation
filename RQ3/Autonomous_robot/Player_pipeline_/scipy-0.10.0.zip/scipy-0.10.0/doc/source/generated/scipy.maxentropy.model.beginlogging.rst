scipy.maxentropy.model.beginlogging
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.beginlogging