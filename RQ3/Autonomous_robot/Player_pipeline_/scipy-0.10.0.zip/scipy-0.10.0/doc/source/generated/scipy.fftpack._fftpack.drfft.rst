scipy.fftpack._fftpack.drfft
============================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: drfft