scipy.interpolate.RectBivariateSpline.integral
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectBivariateSpline.integral