scipy.linalg.kron
=================

.. currentmodule:: scipy.linalg

.. autofunction:: kron