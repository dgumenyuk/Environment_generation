scipy.interpolate.splint
========================

.. currentmodule:: scipy.interpolate

.. autofunction:: splint