scipy.interpolate.LSQBivariateSpline.ev
=======================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.ev