scipy.maxentropy.basemodel.dual
===============================

.. currentmodule:: scipy.maxentropy

.. automethod:: basemodel.dual