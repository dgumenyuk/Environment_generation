scipy.interpolate.InterpolatedUnivariateSpline.set_smoothing_factor
===================================================================

.. currentmodule:: scipy.interpolate

.. automethod:: InterpolatedUnivariateSpline.set_smoothing_factor