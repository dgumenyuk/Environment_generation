scipy.linalg.cho_factor
=======================

.. currentmodule:: scipy.linalg

.. autofunction:: cho_factor