scipy.integrate.dblquad
=======================

.. currentmodule:: scipy.integrate

.. autofunction:: dblquad