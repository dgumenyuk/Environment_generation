scipy.fftpack.cs_diff
=====================

.. currentmodule:: scipy.fftpack

.. autofunction:: cs_diff