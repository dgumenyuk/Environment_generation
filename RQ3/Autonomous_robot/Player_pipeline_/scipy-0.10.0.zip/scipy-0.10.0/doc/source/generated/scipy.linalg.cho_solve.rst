scipy.linalg.cho_solve
======================

.. currentmodule:: scipy.linalg

.. autofunction:: cho_solve