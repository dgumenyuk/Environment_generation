scipy.fftpack.diff
==================

.. currentmodule:: scipy.fftpack

.. autofunction:: diff