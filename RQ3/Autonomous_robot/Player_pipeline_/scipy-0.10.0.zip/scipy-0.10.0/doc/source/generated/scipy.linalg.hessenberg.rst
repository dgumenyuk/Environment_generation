scipy.linalg.hessenberg
=======================

.. currentmodule:: scipy.linalg

.. autofunction:: hessenberg