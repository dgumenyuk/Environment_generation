scipy.maxentropy.bigmodel.expectations
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.expectations