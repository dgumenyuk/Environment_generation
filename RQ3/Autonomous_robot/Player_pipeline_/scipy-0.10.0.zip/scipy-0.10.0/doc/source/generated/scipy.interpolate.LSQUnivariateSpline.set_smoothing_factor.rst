scipy.interpolate.LSQUnivariateSpline.set_smoothing_factor
==========================================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.set_smoothing_factor