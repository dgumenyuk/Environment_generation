scipy.misc.info
===============

.. currentmodule:: scipy.misc

.. autofunction:: info