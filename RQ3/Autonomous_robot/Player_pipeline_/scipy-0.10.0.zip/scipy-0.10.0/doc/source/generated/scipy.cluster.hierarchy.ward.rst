scipy.cluster.hierarchy.ward
============================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: ward