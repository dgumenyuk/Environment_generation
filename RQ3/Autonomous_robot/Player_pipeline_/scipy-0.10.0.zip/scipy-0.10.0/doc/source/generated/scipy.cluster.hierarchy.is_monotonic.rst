scipy.cluster.hierarchy.is_monotonic
====================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: is_monotonic