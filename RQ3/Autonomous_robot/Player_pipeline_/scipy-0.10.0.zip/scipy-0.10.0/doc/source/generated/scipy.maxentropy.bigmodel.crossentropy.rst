scipy.maxentropy.bigmodel.crossentropy
======================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.crossentropy