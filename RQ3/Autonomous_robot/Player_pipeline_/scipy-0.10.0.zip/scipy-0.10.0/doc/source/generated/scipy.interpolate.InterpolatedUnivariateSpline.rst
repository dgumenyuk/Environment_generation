scipy.interpolate.InterpolatedUnivariateSpline
==============================================

.. currentmodule:: scipy.interpolate

.. autoclass:: InterpolatedUnivariateSpline

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         InterpolatedUnivariateSpline.__call__
         InterpolatedUnivariateSpline.derivatives
         InterpolatedUnivariateSpline.get_coeffs
         InterpolatedUnivariateSpline.get_knots
         InterpolatedUnivariateSpline.get_residual
         InterpolatedUnivariateSpline.integral
         InterpolatedUnivariateSpline.roots
         InterpolatedUnivariateSpline.set_smoothing_factor



   

