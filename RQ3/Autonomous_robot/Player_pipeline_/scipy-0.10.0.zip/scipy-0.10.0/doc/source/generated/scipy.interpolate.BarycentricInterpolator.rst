scipy.interpolate.BarycentricInterpolator
=========================================

.. currentmodule:: scipy.interpolate

.. autoclass:: BarycentricInterpolator

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         BarycentricInterpolator.__call__
         BarycentricInterpolator.add_xi
         BarycentricInterpolator.set_yi



   

