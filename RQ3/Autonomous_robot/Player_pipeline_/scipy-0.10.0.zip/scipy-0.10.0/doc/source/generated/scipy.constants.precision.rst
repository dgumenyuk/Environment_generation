scipy.constants.precision
=========================

.. currentmodule:: scipy.constants

.. autofunction:: precision