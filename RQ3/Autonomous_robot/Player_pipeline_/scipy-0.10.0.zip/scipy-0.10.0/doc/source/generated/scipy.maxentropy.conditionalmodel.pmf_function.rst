scipy.maxentropy.conditionalmodel.pmf_function
==============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.pmf_function