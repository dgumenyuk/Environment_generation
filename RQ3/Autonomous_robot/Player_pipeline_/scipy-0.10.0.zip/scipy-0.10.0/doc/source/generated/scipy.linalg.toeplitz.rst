scipy.linalg.toeplitz
=====================

.. currentmodule:: scipy.linalg

.. autofunction:: toeplitz