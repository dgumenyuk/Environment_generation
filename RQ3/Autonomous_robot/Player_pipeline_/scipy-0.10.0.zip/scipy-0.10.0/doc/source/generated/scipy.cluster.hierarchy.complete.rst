scipy.cluster.hierarchy.complete
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: complete