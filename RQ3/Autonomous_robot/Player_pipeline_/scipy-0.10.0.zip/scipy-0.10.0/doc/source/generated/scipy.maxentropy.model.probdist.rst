scipy.maxentropy.model.probdist
===============================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.probdist