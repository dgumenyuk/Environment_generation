scipy.constants.ConstantWarning
===============================

.. currentmodule:: scipy.constants

.. autoexception:: ConstantWarning