scipy.maxentropy.model.pmf_function
===================================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.pmf_function