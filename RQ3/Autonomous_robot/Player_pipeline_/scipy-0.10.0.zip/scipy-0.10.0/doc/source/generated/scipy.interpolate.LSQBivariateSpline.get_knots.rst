scipy.interpolate.LSQBivariateSpline.get_knots
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQBivariateSpline.get_knots