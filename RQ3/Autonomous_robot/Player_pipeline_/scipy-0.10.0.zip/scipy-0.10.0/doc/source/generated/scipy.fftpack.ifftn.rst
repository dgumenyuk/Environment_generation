scipy.fftpack.ifftn
===================

.. currentmodule:: scipy.fftpack

.. autofunction:: ifftn