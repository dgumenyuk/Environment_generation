scipy.ndimage.measurements.center_of_mass
=========================================

.. currentmodule:: scipy.ndimage.measurements

.. autofunction:: center_of_mass