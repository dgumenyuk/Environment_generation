scipy.interpolate.splrep
========================

.. currentmodule:: scipy.interpolate

.. autofunction:: splrep