scipy.interpolate.RectBivariateSpline.get_residual
==================================================

.. currentmodule:: scipy.interpolate

.. automethod:: RectBivariateSpline.get_residual