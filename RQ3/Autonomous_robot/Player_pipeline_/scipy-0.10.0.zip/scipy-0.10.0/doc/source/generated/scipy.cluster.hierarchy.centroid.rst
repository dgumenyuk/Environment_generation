scipy.cluster.hierarchy.centroid
================================

.. currentmodule:: scipy.cluster.hierarchy

.. autofunction:: centroid