scipy.fftpack.dct
=================

.. currentmodule:: scipy.fftpack

.. autofunction:: dct