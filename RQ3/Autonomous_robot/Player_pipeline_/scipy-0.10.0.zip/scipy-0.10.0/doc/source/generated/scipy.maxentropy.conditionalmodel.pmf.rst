scipy.maxentropy.conditionalmodel.pmf
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.pmf