scipy.misc.factorial2
=====================

.. currentmodule:: scipy.misc

.. autofunction:: factorial2