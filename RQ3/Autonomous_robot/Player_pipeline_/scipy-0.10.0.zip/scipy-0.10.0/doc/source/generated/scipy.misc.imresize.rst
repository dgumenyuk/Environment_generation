scipy.misc.imresize
===================

.. currentmodule:: scipy.misc

.. autofunction:: imresize