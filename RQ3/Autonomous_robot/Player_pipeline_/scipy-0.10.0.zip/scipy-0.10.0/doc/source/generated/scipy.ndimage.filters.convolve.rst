scipy.ndimage.filters.convolve
==============================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: convolve