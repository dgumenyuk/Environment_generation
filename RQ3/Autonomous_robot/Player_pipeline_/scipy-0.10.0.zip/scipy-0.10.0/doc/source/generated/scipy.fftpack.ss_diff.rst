scipy.fftpack.ss_diff
=====================

.. currentmodule:: scipy.fftpack

.. autofunction:: ss_diff