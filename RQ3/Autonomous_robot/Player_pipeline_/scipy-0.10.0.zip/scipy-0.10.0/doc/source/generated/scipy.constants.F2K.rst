scipy.constants.F2K
===================

.. currentmodule:: scipy.constants

.. autofunction:: F2K