scipy.linalg.cho_solve_banded
=============================

.. currentmodule:: scipy.linalg

.. autofunction:: cho_solve_banded