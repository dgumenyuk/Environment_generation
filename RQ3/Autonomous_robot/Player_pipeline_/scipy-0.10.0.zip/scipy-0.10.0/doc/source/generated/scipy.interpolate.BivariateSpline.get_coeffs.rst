scipy.interpolate.BivariateSpline.get_coeffs
============================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.get_coeffs