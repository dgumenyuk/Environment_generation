scipy.maxentropy.bigmodel.entropydual
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.entropydual