scipy.io.netcdf.netcdf_variable.shape
=====================================

.. currentmodule:: scipy.io.netcdf

.. autoattribute:: netcdf_variable.shape