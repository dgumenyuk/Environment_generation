scipy.fftpack._fftpack.zfftnd
=============================

.. currentmodule:: scipy.fftpack._fftpack

.. autodata:: zfftnd