scipy.interpolate.LSQUnivariateSpline.roots
===========================================

.. currentmodule:: scipy.interpolate

.. automethod:: LSQUnivariateSpline.roots