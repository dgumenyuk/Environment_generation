scipy.interpolate.SmoothBivariateSpline
=======================================

.. currentmodule:: scipy.interpolate

.. autoclass:: SmoothBivariateSpline

   

   .. HACK -- the point here is that we don't want this to appear in the output, but the autosummary should still generate the pages.
      .. autosummary::
         :toctree:
      
         SmoothBivariateSpline.__call__
         SmoothBivariateSpline.ev
         SmoothBivariateSpline.get_coeffs
         SmoothBivariateSpline.get_knots
         SmoothBivariateSpline.get_residual
         SmoothBivariateSpline.integral



   

