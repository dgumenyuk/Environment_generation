scipy.io.wavfile.write
======================

.. currentmodule:: scipy.io.wavfile

.. autofunction:: write