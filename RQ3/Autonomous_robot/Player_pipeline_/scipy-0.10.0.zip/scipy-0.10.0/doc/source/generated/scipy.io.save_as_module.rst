scipy.io.save_as_module
=======================

.. currentmodule:: scipy.io

.. autofunction:: save_as_module