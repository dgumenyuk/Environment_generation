scipy.io.mminfo
===============

.. currentmodule:: scipy.io

.. autofunction:: mminfo