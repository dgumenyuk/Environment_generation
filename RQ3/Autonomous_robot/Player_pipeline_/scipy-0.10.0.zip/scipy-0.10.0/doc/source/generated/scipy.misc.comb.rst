scipy.misc.comb
===============

.. currentmodule:: scipy.misc

.. autofunction:: comb