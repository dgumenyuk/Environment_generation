scipy.interpolate.griddata
==========================

.. currentmodule:: scipy.interpolate

.. autofunction:: griddata