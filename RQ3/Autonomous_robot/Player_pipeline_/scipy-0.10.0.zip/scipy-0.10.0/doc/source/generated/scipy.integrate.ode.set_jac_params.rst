scipy.integrate.ode.set_jac_params
==================================

.. currentmodule:: scipy.integrate

.. automethod:: ode.set_jac_params