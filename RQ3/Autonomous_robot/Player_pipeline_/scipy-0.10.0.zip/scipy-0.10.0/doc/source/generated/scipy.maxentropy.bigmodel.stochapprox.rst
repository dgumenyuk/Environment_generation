scipy.maxentropy.bigmodel.stochapprox
=====================================

.. currentmodule:: scipy.maxentropy

.. automethod:: bigmodel.stochapprox