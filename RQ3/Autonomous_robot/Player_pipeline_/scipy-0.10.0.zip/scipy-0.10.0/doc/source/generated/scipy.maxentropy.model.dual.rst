scipy.maxentropy.model.dual
===========================

.. currentmodule:: scipy.maxentropy

.. automethod:: model.dual