scipy.maxentropy.conditionalmodel.setcallback
=============================================

.. currentmodule:: scipy.maxentropy

.. automethod:: conditionalmodel.setcallback