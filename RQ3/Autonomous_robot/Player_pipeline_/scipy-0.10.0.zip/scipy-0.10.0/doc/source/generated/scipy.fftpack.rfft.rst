scipy.fftpack.rfft
==================

.. currentmodule:: scipy.fftpack

.. autofunction:: rfft