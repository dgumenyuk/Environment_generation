scipy.interpolate.BivariateSpline.ev
====================================

.. currentmodule:: scipy.interpolate

.. automethod:: BivariateSpline.ev