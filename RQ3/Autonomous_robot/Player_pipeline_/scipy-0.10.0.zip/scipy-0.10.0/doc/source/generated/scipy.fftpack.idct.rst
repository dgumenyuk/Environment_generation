scipy.fftpack.idct
==================

.. currentmodule:: scipy.fftpack

.. autofunction:: idct