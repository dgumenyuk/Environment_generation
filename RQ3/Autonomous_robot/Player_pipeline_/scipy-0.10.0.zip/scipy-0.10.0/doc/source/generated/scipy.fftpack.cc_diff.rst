scipy.fftpack.cc_diff
=====================

.. currentmodule:: scipy.fftpack

.. autofunction:: cc_diff