scipy.constants.F2C
===================

.. currentmodule:: scipy.constants

.. autofunction:: F2C