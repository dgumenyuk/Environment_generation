scipy.linalg.cholesky_banded
============================

.. currentmodule:: scipy.linalg

.. autofunction:: cholesky_banded