scipy.ndimage.filters.maximum_filter
====================================

.. currentmodule:: scipy.ndimage.filters

.. autofunction:: maximum_filter