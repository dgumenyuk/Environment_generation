scipy.interpolate.KroghInterpolator.derivative
==============================================

.. currentmodule:: scipy.interpolate

.. automethod:: KroghInterpolator.derivative