scipy.interpolate.BarycentricInterpolator.__call__
==================================================

.. currentmodule:: scipy.interpolate

.. automethod:: BarycentricInterpolator.__call__